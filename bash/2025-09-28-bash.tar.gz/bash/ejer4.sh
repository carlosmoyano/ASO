#!/bin/bash

read -p "Introduce el primer número: " num1

echo "Introduce el segundo número: "
read num2

echo "Valores introducidos: $num1 y $num2"

