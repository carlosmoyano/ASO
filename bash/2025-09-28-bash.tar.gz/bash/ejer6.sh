#!/bin/bash

read -p "Introduce una palabra: " palabra
echo $palabra >> ./lista.txt





